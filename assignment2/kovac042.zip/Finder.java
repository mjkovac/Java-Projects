package assignment2;


public class Finder {
    public static int findMaximumValueTag(int[] input) {
        int maxElement = -100;
        return maxElement;
    }
}