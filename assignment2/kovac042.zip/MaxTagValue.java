package assignment2;

public interface MaxTagValue {

    /**
     * The method returns an integer. 
     * The integer is the greatest value of all tagValues of the lab devices
     */
    int findMaximumValueTag();
}