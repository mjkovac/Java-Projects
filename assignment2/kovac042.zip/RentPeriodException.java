package assignment2;

public class RentPeriodException extends Exception {
    
    /**
	 * Generated serial version
	 */
	private static final long serialVersionUID = 6072958001347514800L;

	public RentPeriodException() {}
    
    public RentPeriodException(String message) {
        super(message);
    }
}